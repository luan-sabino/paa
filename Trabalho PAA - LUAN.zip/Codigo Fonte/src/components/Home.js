import { useState } from "react";
import { Link } from "react-router-dom";

export default function Home(){

    return(
    <div className="w-screen h-screen flex flex-col justify-center items-center">
        <p className="text-5xl font-semibold tracking-widest p-7"> Algoritmos de Ordenação </p>
        <div className="grid grid-cols-3 p-10">
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="BSC">Bubble Sort Normal</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="BSP">Bubble Sort Aprimorado</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="QSFE">QuickSort Primeiro Elemento</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="QSME">Quicksort Elemento Central</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="IS">Insertion Sort</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="SS">Shell Sort</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="SnS">Selection Sort</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="HS">Heap Sort</Link>
            </button>
            <button className=" p-2 m-2 border-b border-cyan-200 rounded hover:bg-cyan-100">
                <Link to="MS">Merge Sort</Link>
            </button>
        </div>    
    </div>
    );
}